package com.example.aplicacaobancodedados;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BancoDeDadosActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banco_de_dados);




    }

    public class MainActivity extends Activity{

        Button btcriarbanco;
        Button btcadastrardados;
        Button btcadastrardados2;
        Button btconsultardados;
        Button btalterardados;
        Button btalterardados2;
        SQLiteDatabase db;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            setContentView(R.layout.activity_main);
            btcriarbanco = (Button) findViewById(R.id.btcriarbanco);

            btalterardados2 = findViewById(R.id.btcadastrardados2);

            btalterardados2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent alterarDados2Activity = new Intent (MainActivity.this,
                            AlterarDadosActivity.class);
                    MainActivity.this.startActivity(alterarDados2Activity);
                }
            });
        }

    }
}